
# /sh 文件夹下包含训练和推理需要的脚步，可以一键运行
# /logs 文件夹存储 训练时 的log文件
# /predict_logs 文件夹存储 推理时 的log文件
# /results 文件夹存储 推理时 保存的结果