python run.py \
    --split test_annotation \
    --dia_path xxx/dialogue.json