

example={
    "openness":openness_example,
    "conscientiousness":conscientiousness_example,
    "extraversion":extraversion_example,
    "agreeableness":agreeableness_example,
    "neuroticism":neuroticism_example
}
